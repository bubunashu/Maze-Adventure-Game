using Microsoft.VisualStudio.TestTools.UnitTesting;
using MazeAdventure.Controllers;
using MazeAdventure.MazeIntegrate;
using MazeAdventure.Utility;
using MazeAdventure;
using Microsoft.AspNetCore.Mvc;

namespace MazeAdventureUnitTest
{
    [TestClass]
    public class MazeAdventureTest
    {
        private IMazeIntegration _mazeInegrationObj;
        private MazeController _mazeObj;
        private IBusinessUtility _businessUtilityObj;

        static MazeAdventureTest()
        {
            Constant.roomIDWithDimension = MockData.GetMazeData();
            Constant.roomDetails = MockData.GetTestRoomDetail();
            Constant.treasureAndEntranceList = MockData.GetTestTreasureAndEntrances();
        }
        [TestInitialize]
        public void SetUp()
        {
            _mazeInegrationObj = new MazeIntegration(_businessUtilityObj);
            _mazeObj = new MazeController(_mazeInegrationObj);
           }
        [TestMethod]
        public void GetEntranceRoomTest()
        {                     
            var response = _mazeObj.GetEntranceRoom() as ObjectResult;
            Assert.IsTrue((int)response.Value == 882 && response.StatusCode==200, "Passed!");
        }
        [TestMethod]
        public void GetRoomTest()
        {
            var response = _mazeObj.GetRoom(882,'N') as ObjectResult;
            Assert.IsTrue((int)response.Value == 885 && response.StatusCode == 200, "Passed!");
        }
        [TestMethod]
        public void GetDescriptionTest()
        {
            var response = _mazeObj.GetDescription(886) as ObjectResult;
            Assert.IsTrue((string)response.Value == "This is a forest" && response.StatusCode == 200, "Passed!");
        }
        [TestMethod]
        public void HasTreasureTest()
        {
            var response = _mazeObj.HasTreasure(887) as ObjectResult;
            Assert.IsTrue((bool)response.Value == true && response.StatusCode == 200, "Passed!");
        }
        [TestMethod]
        public void CausesInjuryTest()
        {
            var response = _mazeObj.CausesInjury(888) as ObjectResult;
            Assert.IsTrue(((bool)response.Value == true || (bool)response.Value == false) && response.StatusCode == 200, "Passed!");
        }
    }
}
