﻿using MazeAdventure.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace MazeAdventureUnitTest
{
    class MockData
    {
        public static Dictionary<int, int[]> roomIDWithDimension = new Dictionary<int, int[]>();
        public static List<Room> roomListDetail = new List<Room>();
        public static List<TreasureAndEntrance> treasureAndEntrance = new List<TreasureAndEntrance>();
        public static  Dictionary<int, int[]>  GetMazeData()
        {
            roomIDWithDimension.Add(880, new int[] { 0,0, 10, 100 });
            roomIDWithDimension.Add(881, new int[] { 0,1, 12, 100 });
            roomIDWithDimension.Add(882, new int[] { 0,2, 12, 102 });
            roomIDWithDimension.Add(883, new int[] { 1,0, 10, 100 });
            roomIDWithDimension.Add(884, new int[] { 1,1, 12, 100 });
            roomIDWithDimension.Add(885, new int[] { 1,2, 11, 100 });
            roomIDWithDimension.Add(886, new int[] { 2,0, 10, 100 });
            roomIDWithDimension.Add(887, new int[] { 2,1, 10, 101 });
            roomIDWithDimension.Add(888, new int[] { 2,2, 13, 100 });
            return roomIDWithDimension;
        }        
        public static List<Room> GetTestRoomDetail()
        {
            roomListDetail.Add(new Room() { RoomTypeId = 10, RoomName = "Forest", RoomDescription = "This is a forest", RoomEndPercent = 0, IsTrap = false });
            roomListDetail.Add(new Room() { RoomTypeId = 11, RoomName = "Desert", RoomDescription = "This is a forest", RoomEndPercent = 20, IsTrap = true });
            roomListDetail.Add(new Room() { RoomTypeId = 12, RoomName = "Hills", RoomDescription = "This is a forest", RoomEndPercent = 0, IsTrap = false });
            roomListDetail.Add(new Room() { RoomTypeId = 13, RoomName = "Marsh", RoomDescription = "This is a forest", RoomEndPercent = 30, IsTrap = true });
            return roomListDetail;
        }
        public static List<TreasureAndEntrance> GetTestTreasureAndEntrances()
        {
            treasureAndEntrance.Add(new TreasureAndEntrance() { roomTreasureAndEntranceId = 100, roomDefinition = "None" });
            treasureAndEntrance.Add(new TreasureAndEntrance() { roomTreasureAndEntranceId = 101, roomDefinition = "TreasureRoom" });
            treasureAndEntrance.Add(new TreasureAndEntrance() { roomTreasureAndEntranceId = 102, roomDefinition = "Entrance" });
            return treasureAndEntrance;
        }

    }
}
