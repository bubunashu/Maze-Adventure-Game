﻿using MazeAdventure.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MazeAdventure
{
    public static class Constant
    {
        public static Dictionary<int, int[]> roomIDWithDimension = new Dictionary<int, int[]>();
        public static int[,] finalArrayMaze;
        public static string noRoomMesage = "No Room description is available for this room Id.";  
        public static List<Room> roomDetails = new List<Room>();
        public static List<TreasureAndEntrance> treasureAndEntranceList = new List<TreasureAndEntrance>();
        public static List<Room> GetRoomDetail()
        {

            roomDetails.Add(new Room() { RoomTypeId = 200, RoomName = "Forest", RoomDescription = "You are looking at a heap of leaves and feel slightly elated", RoomEndPercent = 0, IsTrap = false });
            roomDetails.Add(new Room() { RoomTypeId = 201, RoomName = "Desert", RoomDescription = "A desert is a barren area of landscape where little precipitation occurs ", RoomEndPercent = 20, IsTrap = true });
            roomDetails.Add(new Room() { RoomTypeId = 202, RoomName = "Hills", RoomDescription = "You are looking at a naturally raised area of land, not as high or craggy as a mountain.", RoomEndPercent = 0, IsTrap = false });
            roomDetails.Add(new Room() { RoomTypeId = 203, RoomName = "Marsh", RoomDescription = "You are looking at an area of low-lying land which is flooded in wet seasons or at high tide", RoomEndPercent = 30, IsTrap = true });
            return roomDetails;
        }
        public static List<TreasureAndEntrance> GetTreasureAndEntrances()
        {
            treasureAndEntranceList.Add(new TreasureAndEntrance() { roomTreasureAndEntranceId = 1000, roomDefinition = "None" });
            treasureAndEntranceList.Add(new TreasureAndEntrance() { roomTreasureAndEntranceId = 1001, roomDefinition = "TreasureRoom" });
            treasureAndEntranceList.Add(new TreasureAndEntrance() { roomTreasureAndEntranceId = 1002, roomDefinition = "Entrance" });
            return treasureAndEntranceList;
        }
    }
}
        
