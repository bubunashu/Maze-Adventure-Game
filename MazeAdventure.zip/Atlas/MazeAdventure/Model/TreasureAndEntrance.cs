﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MazeAdventure.Model
{
    public class TreasureAndEntrance
    {
        public int roomTreasureAndEntranceId { get; set; }
        public string roomDefinition { get; set; }
    }
}
