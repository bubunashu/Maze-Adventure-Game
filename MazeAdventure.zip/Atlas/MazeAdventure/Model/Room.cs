﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MazeAdventure.Model
{
    public class Room
    {
        public int RoomTypeId { get; set; }
        public string RoomName { get; set; }
        public string RoomDescription { get; set; }
        public double RoomEndPercent { get; set; }
        public bool IsTrap { get; set; }
    }
}
