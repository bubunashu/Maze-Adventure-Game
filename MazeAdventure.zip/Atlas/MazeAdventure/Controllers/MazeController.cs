﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MazeAdventure.Model;
using MazeAdventure.Utility;
using MazeAdventure.MazeIntegrate;

namespace MazeAdventure.Controllers
{
    [Produces("application/json")]
    [Route("api/Maze/[action]")]
    public class MazeController : Controller
    {
        private readonly IMazeIntegration _mazeInegrationObj;
       
        public MazeController(IMazeIntegration mazeInegrationObj)
        {
            _mazeInegrationObj = mazeInegrationObj;
        }

        [HttpGet("{size}")]
        [ActionName("BuildMaze")]
        public IActionResult BuildMaze(int size)
        {
            try
            {
                _mazeInegrationObj.BuildMaze(size);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("{roomId}")]
        [ActionName("GetDescription")]
        public IActionResult GetDescription(int roomId)
        {
            try
            {
                var description = _mazeInegrationObj.GetDescription(roomId);
                return Ok(description);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("{roomId}")]
        [ActionName("HasTreasure")]
        public IActionResult HasTreasure(int roomId)
        {
            try
            {
                var hasTreasure = _mazeInegrationObj.HasTreasure(roomId);
                return Ok(hasTreasure);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet]
        [ActionName("GetEntranceRoom")]
        public IActionResult GetEntranceRoom()
        {
            try
            {
                var entranceRoomId = _mazeInegrationObj.GetEntranceRoom();
                return Ok(entranceRoomId);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("{roomId}")]
        [ActionName("CausesInjury")]
        public IActionResult CausesInjury(int roomId)
        {
            try
            {
                var causesInjury = _mazeInegrationObj.CausesInjury(roomId);
                return Ok(causesInjury);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("{roomId}/{direction}")]
        [ActionName("GetRoom")]
        public IActionResult GetRoom(int roomId, char direction)
        {
            try
            {
                var roomDetails = _mazeInegrationObj.GetRoom(roomId, direction);
                return Ok(roomDetails);
                
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}