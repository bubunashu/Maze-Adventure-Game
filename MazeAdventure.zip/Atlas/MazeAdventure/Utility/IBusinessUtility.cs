﻿using MazeAdventure.MazeIntegrate;

namespace MazeAdventure.Utility
{
    public interface IBusinessUtility
    {
        int GenerateRandomRoomFromList();
        int GenerateRandomTreasureOrNoneFromList();
    }
}
