﻿using System.Linq;
using MazeAdventure.MazeIntegrate;


namespace MazeAdventure.Utility
{
    public class BusinessUtility:IBusinessUtility
    {
        public int GenerateRandomRoomFromList()
        {
            return MazeIntegration.rndNumber.Next(Constant.roomDetails[0].RoomTypeId, Constant.roomDetails[Constant.roomDetails.Count - 1].RoomTypeId + 1);
        }

        public int GenerateRandomTreasureOrNoneFromList()
        {
            return MazeIntegration.rndNumber.Next(Constant.treasureAndEntranceList[0].roomTreasureAndEntranceId, Constant.treasureAndEntranceList[2].roomTreasureAndEntranceId);
        }
    }
}
