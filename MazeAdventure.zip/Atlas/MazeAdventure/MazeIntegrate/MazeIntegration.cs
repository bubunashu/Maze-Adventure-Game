﻿using MazeAdventure.Model;
using MazeAdventure.Utility;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MazeAdventure.MazeIntegrate
{
    public class MazeIntegration : IMazeIntegration
    {
        public static Random rndNumber = new Random();
        private readonly IBusinessUtility _mazeBusinessUtility;
        public MazeIntegration(IBusinessUtility mazeBusinessUtility)
        {
            _mazeBusinessUtility = mazeBusinessUtility;
        }
        /// <summary>
        /// Generate Maze with predefined size
        /// </summary>
        /// <param name="size"></param>
        public void BuildMaze(int size)
        {
            if (Constant.roomIDWithDimension.Count.Equals(0))
            {
                Constant.roomDetails = Constant.GetRoomDetail(); //Retrieve all Room Details
                var trapRoomIdList = new List<int>();

                /*Get all the room details which has Trap*/
                for (int roomCount = 0; roomCount < Constant.roomDetails.Count; roomCount++)
                {
                    if (Constant.roomDetails[roomCount].IsTrap == true)
                    {
                        trapRoomIdList.Add(Constant.roomDetails[roomCount].RoomTypeId);
                    }
                }
                Constant.treasureAndEntranceList = Constant.GetTreasureAndEntrances();//Get Treasure and Entrance Room Details       
                int[,] arrMaze = new int[size, size];
                int roomId = rndNumber.Next(1, 1000);
                var roomList = new List<int>(); //List will be filled with room type Id, Treasure and Entrance Id once found
                var entrance = new Dictionary<int, int[]>();
                /* Assuming the entrance room to be one of the corners of the Maze*/
                entrance.Add(0, new int[] { 0, 0 });
                entrance.Add(1, new int[] { 0, size - 1 });
                entrance.Add(2, new int[] { size - 1, 0 });
                entrance.Add(3, new int[] { size - 1, size - 1 });
                int index = rndNumber.Next(entrance.Count); // Select entrance from the four corners randomly
                int roomTypeVal = rndNumber.Next(Constant.roomDetails[0].RoomTypeId, Constant.roomDetails[Constant.roomDetails.Count - 1].RoomTypeId + 1);// Generate the room type Id randomly from Room Details
                while (trapRoomIdList.Contains(roomTypeVal))
                {
                    /*Generate the room unless you get the room without trap as Entrance room can not have trap*/
                    roomTypeVal = _mazeBusinessUtility.GenerateRandomRoomFromList();
                }
                arrMaze[entrance[index][0], entrance[index][1]] = roomTypeVal;
                Constant.roomIDWithDimension.Add(roomId++, new int[] { entrance[index][0], entrance[index][1], roomTypeVal, Constant.treasureAndEntranceList[2].roomTreasureAndEntranceId });
                roomList.Add(Constant.treasureAndEntranceList[2].roomTreasureAndEntranceId);
                /* Assuming the entrance room to be one of the corners of the Maze*/
                for (int rowCount = 0; rowCount < size; rowCount++)
                {
                    for (int columnCount = 0; columnCount < size; columnCount++)
                    {
                        if ((rowCount == entrance[index][0] && columnCount == entrance[index][1]))
                        {
                            continue; //Continue the loop if rowCount and columnCount are same as entrance's rowCount and columnCount
                        }
                        if (rowCount == size - 1 && columnCount == size - 1 && arrMaze[rowCount, columnCount].Equals(0))
                        {
                            /*Generate treasure room for the last cell in the Maze if it is not an entrance room, blank and treasure room is not decided*/
                            if (!roomList.Contains(Constant.treasureAndEntranceList[1].roomTreasureAndEntranceId))
                            {
                                int roomTypeId = _mazeBusinessUtility.GenerateRandomRoomFromList();
                                while (trapRoomIdList.Contains(roomTypeId))
                                {
                                    roomTypeId = _mazeBusinessUtility.GenerateRandomRoomFromList();
                                }
                                arrMaze[size - 1, size - 1] = roomTypeId;
                                Constant.roomIDWithDimension.Add(roomId++, new int[] { size - 1, size - 1, roomTypeId, Constant.treasureAndEntranceList[1].roomTreasureAndEntranceId });
                                roomList.Add(Constant.treasureAndEntranceList[1].roomTreasureAndEntranceId);
                            }
                            else
                            {
                                /*If the last cell is treasure room, generate any room (Neither Treasure nor Entrance)*/
                                int roomTypeId = _mazeBusinessUtility.GenerateRandomRoomFromList();
                                arrMaze[size - 1, size - 1] = roomTypeId;
                                Constant.roomIDWithDimension.Add(roomId++, new int[] { size - 1, size - 1, roomTypeId, Constant.treasureAndEntranceList[0].roomTreasureAndEntranceId });
                                roomList.Add(Constant.treasureAndEntranceList[0].roomTreasureAndEntranceId);
                            }
                        }
                        else if (rowCount == size - 1 && columnCount == size - 1 && !arrMaze[rowCount, columnCount].Equals(0))
                        {
                            /*if the last cell is not empty and treasure room is still not decided, make it the treasure room*/
                            if (!roomList.Contains(Constant.treasureAndEntranceList[1].roomTreasureAndEntranceId))
                            {
                                roomList.Add(Constant.treasureAndEntranceList[1].roomTreasureAndEntranceId);
                                int roomTypeId = _mazeBusinessUtility.GenerateRandomRoomFromList();
                                while (trapRoomIdList.Contains(roomTypeId))
                                {
                                    roomTypeId = _mazeBusinessUtility.GenerateRandomRoomFromList();
                                }
                                int randomRow = rndNumber.Next(0, rowCount);
                                int randomColumn = rndNumber.Next(0, columnCount);
                                arrMaze[randomRow, randomColumn] = roomTypeId;
                                var key = Constant.roomIDWithDimension.FirstOrDefault(x => x.Value[0] == randomRow && x.Value[1] == randomColumn).Key;
                                var updatedValue = new int[] { randomRow, randomColumn, roomTypeId, Constant.treasureAndEntranceList[1].roomTreasureAndEntranceId };
                                Constant.roomIDWithDimension[key] = updatedValue;
                                roomList.Add(Constant.treasureAndEntranceList[2].roomTreasureAndEntranceId);
                            }
                        }
                        else
                        {
                            /*Randomly Generate RoomTypeId from RoomDetails and tresure/None from treasureAndEntranceList */
                            int roomTypeId = _mazeBusinessUtility.GenerateRandomRoomFromList();
                            int treasureOrEntrance = _mazeBusinessUtility.GenerateRandomTreasureOrNoneFromList();
                            /* If the selected roomType is a trap and treasure, generate new roomType Id unless the room type is not trap */
                            if ((trapRoomIdList.Contains(roomTypeId) && treasureOrEntrance == Constant.treasureAndEntranceList[1].roomTreasureAndEntranceId))
                            {
                                while (trapRoomIdList.Contains(roomTypeId))
                                {
                                    roomTypeId = _mazeBusinessUtility.GenerateRandomRoomFromList();
                                }
                            }
                            /*If roomlist already contains a treasure, generate unless a None type found*/
                            if ((roomList.Contains(Constant.treasureAndEntranceList[1].roomTreasureAndEntranceId)))
                            {
                                while (treasureOrEntrance == Constant.treasureAndEntranceList[1].roomTreasureAndEntranceId)
                                {
                                    treasureOrEntrance = _mazeBusinessUtility.GenerateRandomTreasureOrNoneFromList();
                                }
                            }
                            arrMaze[rowCount, columnCount] = roomTypeId;
                            Constant.roomIDWithDimension.Add(roomId++, new int[] { rowCount, columnCount, roomTypeId, treasureOrEntrance });
                            if (!roomList.Contains(treasureOrEntrance))
                            {
                                roomList.Add(treasureOrEntrance);
                            }
                            if (!roomList.Contains(roomTypeId))
                            {
                                roomList.Add(roomTypeId);
                            }
                        }
                    }
                }
                Constant.finalArrayMaze = arrMaze;
            }
        }
        /// <summary>
        /// Checks whether a room causes injury to the player.
        /// </summary>
        /// <param name="roomId"></param>
        /// <returns></returns>
        public bool CausesInjury(int roomId)
        {
            var rndm = new Random();
            double percentChanceOfDamage = 0;
            for (int roomCount = 0; roomCount < Constant.roomDetails.Count; roomCount++)
            {
                if (Constant.roomDetails[roomCount].RoomTypeId == Constant.roomIDWithDimension[roomId][2])
                {
                    percentChanceOfDamage = Constant.roomDetails[roomCount].RoomEndPercent;
                }
            }
            if (!percentChanceOfDamage.Equals(0))
            {
                int enrtyToRoom = rndm.Next(1, 101);
                if (enrtyToRoom < percentChanceOfDamage)
                {
                    for (int count = 0; count < Constant.roomDetails.Count; count++)
                    {
                        if (Constant.roomDetails[count].RoomTypeId == Constant.roomIDWithDimension[roomId][2])
                        {
                            Constant.roomDetails[count].RoomDescription = Constant.roomDetails[count].RoomDescription + " || Behavior modifier appended ||";
                        }
                    }
                    return true;
                }
                else return false;
            }
            else return false;           
        }
        /// <summary>
        /// Gets the computed textual description of the passed room.
        /// </summary>
        /// <param name="roomId"></param>
        /// <returns></returns>
        public string GetDescription(int roomId)
        {

            for (int roomCount=0; roomCount< Constant.roomDetails.Count; roomCount++)
            {
                if(Constant.roomDetails[roomCount].RoomTypeId == Constant.roomIDWithDimension[roomId][2])
                {
                    return Constant.roomDetails[roomCount].RoomDescription;
                }
            }
            return Constant.noRoomMesage;
        }
        /// <summary>
        /// Gets the ID of the entrance room for the built maze.
        /// </summary>
        /// <returns></returns>
        public int GetEntranceRoom()
        {
            var key = Constant.roomIDWithDimension.FirstOrDefault(x => x.Value[3] == Constant.treasureAndEntranceList[2].roomTreasureAndEntranceId).Key;
            return key;
        }
        /// <summary>
        /// Gets the room adjacent to the passed room, given a direction. NULL signals invalid room, i.e. edge of the maze.
        /// </summary>
        /// <param name="roomId"></param>
        /// <param name="direction"></param>
        /// <returns></returns>
        public int? GetRoom(int roomId, char direction)
        {
            int roomIdDetail = 0;
            int maxVal = (int)Math.Sqrt(Constant.roomIDWithDimension.Count)-1;
            char direct = Char.ToUpper(direction);
            int entranceRoomId = GetEntranceRoom();
            if (Constant.roomIDWithDimension[entranceRoomId][0] == 0)
            {
                if(Char.ToUpper(direction) == 'N') direct = 'S';
                if (Char.ToUpper(direction) == 'E') direct = 'W';
                if (Char.ToUpper(direction) == 'W') direct = 'E';
                if (Char.ToUpper(direction) == 'S') direct = 'N';
            }
            int rowVal = Constant.roomIDWithDimension[roomId][0];
            int columnVal = Constant.roomIDWithDimension[roomId][1];
            if (direct == 'N')
            {
                rowVal = rowVal - 1 >= 0 && rowVal -1 <=maxVal?rowVal-1:-1;
                if (rowVal == -1) return null;
            }
            if (direct == 'S')
            {
                rowVal = rowVal + 1 >= 0 && rowVal + 1 <= maxVal ? rowVal + 1 : -1;
                if (rowVal == -1) return null;
            }
                
            if (direct == 'E')
            {
                columnVal = columnVal + 1 >= 0 && columnVal + 1 <= columnVal ? columnVal + 1 : -1;
                if (columnVal == -1) return null;
            }
            if (direct == 'W')
            {
                columnVal = columnVal - 1 >= 0 && columnVal - 1 <= columnVal ? columnVal - 1 : -1;
                if (columnVal == -1) return null;
            }
            roomIdDetail = Constant.roomIDWithDimension.FirstOrDefault(x => x.Value[0] == rowVal && x.Value[1] == columnVal).Key;
            CausesInjury(roomIdDetail);
            return roomIdDetail;
        }
        /// <summary>
        /// Check if the room has treasure or not
        /// </summary>
        /// <param name="roomId"></param>
        /// <returns></returns>
        public bool HasTreasure(int roomId)
        {
            if (Constant.roomIDWithDimension[roomId][3] == Constant.treasureAndEntranceList[1].roomTreasureAndEntranceId)
            {
                return true;
            }
            else return false;
        }    
    }
}
